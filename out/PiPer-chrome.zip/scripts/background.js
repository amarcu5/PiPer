var a;a||(a=!0,(()=>{'use strict';chrome.runtime.onInstalled.addListener(function(a){"install"==a.reason&&chrome.tabs.create({url:chrome.extension.getURL("install.html")})});})());
